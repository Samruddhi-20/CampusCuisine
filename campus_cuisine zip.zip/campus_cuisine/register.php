<?php
$servername = "localhost"; // Change this to your MySQL server hostname
$username = "root"; // Change this to your MySQL username
$password = ""; // Change this to your MySQL password
$dbname = "university"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Escape user inputs for security
$full_name = $conn->real_escape_string($_POST['fullName']);
$student_id = $conn->real_escape_string($_POST['studentID']);
$email = $conn->real_escape_string($_POST['email']);
$phone = $conn->real_escape_string($_POST['phone']);
$room_number = $conn->real_escape_string($_POST['roomNumber']);
$subscription_plan = $conn->real_escape_string($_POST['subscriptionPlan']);

// Insert data into database
$sql = "INSERT INTO students (full_name, student_id, email, phone, room_number, subscription_plan) VALUES ('$full_name', '$student_id', '$email', '$phone', '$room_number', '$subscription_plan')";
if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>