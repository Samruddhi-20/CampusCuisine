<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "messmanagement";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate form fields
    $errors = [];
    $fullName = $_POST['fullName'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $complaint = $_POST['complaint'];

    if (empty($fullName)) {
        $errors[] = "Full Name is required";
    }

    if (empty($email)) {
        $errors[] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }

    if (empty($subject)) {
        $errors[] = "Subject is required";
    }

    if (empty($complaint)) {
        $errors[] = "Complaint is required";
    }

    // If there are no errors, insert data into database
    if (empty($errors)) {
        // Prepare and bind SQL statement
        $stmt = $conn->prepare("INSERT INTO complaints (full_name, email, subject, complaint) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $fullName, $email, $subject, $complaint);

        // Execute the statement
        if ($stmt->execute() === TRUE) {
            echo "<h2>Your complaint has been submitted successfully!</h2>";
        } else {
            echo "<h2>Error: " . $stmt->error . "</h2>";
        }

        // Close statement
        $stmt->close();
    } else {
        // If there are errors, display them to the user
        echo "<h2>There were errors with your submission:</h2>";
        echo "<ul>";
        foreach ($errors as $error) {
            echo "<li>$error</li>";
        }
        echo "</ul>";
    }
}

// Close database connection
$conn->close();
?>
